package crbs.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
 
import crbs.beans.AdminAccount;
import crbs.beans.UserAccount;
import crbs.beans.Room;
import crbs.beans.Booking;

 
public class DBUtils {
	
    public static UserAccount findUserAccount(Connection conn, String userName, String password) throws SQLException {
 
        String sql = "Select  a.Name, a.Email, a.Phone, a.UserName, a.Password, a.UserID from user_account a " + " where a.UserName = ? and a.Password= ?";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setString(1, userName);
        pstm.setString(2, password);
        ResultSet rs = pstm.executeQuery();
 
        if (rs.next()) {
            
        	int userID = Integer.parseInt(rs.getString("UserID"));
        	String name = rs.getString("Name");
        	String email = rs.getString("Email");
        	String phone = rs.getString("Phone");
            UserAccount user = new UserAccount();
            user.setUserID(userID);
            user.setName(name);
            user.setEmail(email);
            user.setPhone(phone);
            user.setUserName(userName);
            user.setPassword(password);
           
            return user;
        }
        return null;
    }
    
    
    public static AdminAccount findAdmin(Connection conn, String adminName,String password) throws SQLException {
    	
    	String sql = "Select a.AdminName, a.Password, a.Gender from admin_account a "+ "where a.AdminName = ? and a.Password= ?";
    	
    	PreparedStatement pstm = conn.prepareStatement(sql);
    	pstm.setString(1, adminName);
    	pstm.setString(2, password);
    	ResultSet rs = pstm.executeQuery();
    	
    	if (rs.next()){
    		
    		String gender= rs.getString("Gender");
    		AdminAccount admin = new AdminAccount();
    		admin.setAdminName(adminName);
    		admin.setPassword(password);
    		admin.setGender(gender);
    		return admin;
    	}
    	return null;
    }
    
    public static AdminAccount findAdmin(Connection conn, String adminName) throws SQLException {
    	
    	String sql = "Select a.AdminName, a.Password, a.Gender from admin_account a where a.AdminName = ? ";
    	
    	PreparedStatement pstm = conn.prepareStatement(sql);
    	pstm.setString(1, adminName);
      	ResultSet rs = pstm.executeQuery();
    	
    	if (rs.next()){
    		String password=rs.getString("Password");
    		String gender= rs.getString("Gender");
    		
    		AdminAccount admin= new AdminAccount(adminName,password,gender);
    		
    		return admin;
    	}
    	return null;
    }
    
    public static UserAccount findUserAccount(Connection conn, String userName) throws SQLException {
        String sql = "Select a.Name, a.Email, a.Phone, a.UserName, a.Password, a.UserID from user_account a where a.UserName=?";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setString(1,userName);
   
 
        ResultSet rs = pstm.executeQuery();
 
        while (rs.next()) {
            String name = rs.getString("Name");
            String email = rs.getString("Email");
            String phone = rs.getString("Phone");
            String password = rs.getString("Password");
            int userID = Integer.parseInt(rs.getString("userID"));
            

            UserAccount user = new UserAccount(userID,name, email, phone, userName, password);
            return user;
        }
        return null;
    }
    
    public static Room findRoom(Connection conn, int roomID) throws SQLException {
        String sql = "Select a.RoomID, a.RoomName, a.RoomCapacity from rooms a where a.RoomID=?";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1,roomID);
   
 
        ResultSet rs = pstm.executeQuery();
 
        while (rs.next()) {
            String roomName = rs.getString("RoomName");
            int roomCapacity = Integer.parseInt(rs.getString("RoomCapacity"));
           
            Room room = new Room(roomID, roomName, roomCapacity);
            return room;
        }
        return null;
    }
	
	public static List<UserAccount> queryUser(Connection conn) throws SQLException {
        String sql = "Select a.UserID, a.Name, a.Email, a.Phone, a.UserName, a.Password from user_account a ";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        ResultSet rs = pstm.executeQuery();
        List<UserAccount> list = new ArrayList<UserAccount>();
        while (rs.next()) {
        	int userID = Integer.parseInt(rs.getString("UserID"));
            String name = rs.getString("Name");
            String email = rs.getString("Email");
            String phone = rs.getString("Phone");
            String userName = rs.getString("UserName");
            String password = rs.getString("Password");
            UserAccount user = new UserAccount();
            user.setUserID(userID);
            user.setName(name);
            user.setEmail(email);
            user.setPhone(phone);
            user.setUserName(userName);
            user.setPassword(password);
            list.add(user);
        }
        return list;
    } 
 
    public static void insertUserAccount(Connection conn, UserAccount user) throws SQLException {
        String sql = "Insert into user_account(Name, Email, Phone, UserName, Password, UserID) values (?,?,?,?,?,?)";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        pstm.setInt(6, user.getUserID());
        pstm.setString(1, user.getName());
        pstm.setString(2, user.getEmail());
        pstm.setString(3, user.getPhone());
        pstm.setString(4, user.getUserName());
        pstm.setString(5, user.getPassword());
        
 
        pstm.executeUpdate();
    }
 
    public static void updateUserAccount(Connection conn, UserAccount user) throws SQLException {
        String sql = "Update user_account set Name=?, Email=?, Phone=?, Password=?, UserID=? where UserName=? ";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
        
        pstm.setString(1, user.getName());
        pstm.setString(2, user.getEmail());
        pstm.setString(3, user.getPhone());
        pstm.setString(4, user.getPassword());
        pstm.setInt(5, user.getUserID());
        pstm.setString(6, user.getUserName());
        
        pstm.executeUpdate();
    }
    
    public static void deleteUser(Connection conn, String userName) throws SQLException {
        String sql = "Delete From user_account where UserName= ?";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        pstm.setString(1, userName);
 
        pstm.executeUpdate();
    }
    
	public static List<Room> queryRoom(Connection conn) throws SQLException {
        String sql = "Select a.RoomID, a.RoomName, a.RoomCapacity from rooms a ";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        ResultSet rs = pstm.executeQuery();
        List<Room> list = new ArrayList<Room>();
        while (rs.next()) {
            int roomID = rs.getInt("RoomID");
            String roomName = rs.getString("RoomName");
            int roomCapacity = rs.getInt("RoomCapacity");
        
            Room room = new Room();
            room.setRoomID(roomID);
            room.setRoomName(roomName);
            room.setRoomCapacity(roomCapacity);
           
            list.add(room);
        }
        return list;
    } 
 
    public static void insertRoom(Connection conn, Room room) throws SQLException {
        String sql = "Insert into rooms(RoomID, RoomName, RoomCapacity) values (?,?,?)";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        pstm.setInt(1, room.getRoomID());
        pstm.setString(2, room.getRoomName());
        pstm.setInt(3, room.getRoomCapacity());        
 
        pstm.executeUpdate();
    }
 
    public static void updateRoom(Connection conn, Room room) throws SQLException {
        String sql = "Update rooms set RoomName =?, RoomCapacity=? where RoomID=? ";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        pstm.setString(1, room.getRoomName());
        pstm.setInt(2, room.getRoomCapacity());
        pstm.setInt(3, room.getRoomID());
        pstm.executeUpdate();
    }
    public static void deleteRoom(Connection conn, int roomID) throws SQLException {
        String sql = "Delete From rooms where RoomID= ?";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        pstm.setInt(1, roomID);
 
        pstm.executeUpdate();
    }
    
    public static void insertBooking(Connection conn, Booking book) throws SQLException {
        String sql = "Insert into events(id, title, startDate, startTime, endDate, endTime, roomId, userName) values (?,?,?,?,?,?,?,?)";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        pstm.setInt(1, book.getId());
        pstm.setString(2, book.getTitle());
        pstm.setString(3, book.getStartDate());
        pstm.setString(4, book.getStartTime());
        pstm.setString(5, book.getEndDate());
        pstm.setString(6, book.getEndTime());
        pstm.setInt(7, book.getRoomId());
        pstm.setString(8, book.getUserName());
        
 
        pstm.executeUpdate();
    }
    
    public static List<Booking> queryBooking(Connection conn) throws SQLException {
        String sql = "Select a.id, a.title, a.startDate, a.startTime, a.endDate, a.endTime, a.roomId, a.userName from events a ";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        ResultSet rs = pstm.executeQuery();
        List<Booking> list = new ArrayList<Booking>();
        while (rs.next()) {
        	int id = Integer.parseInt(rs.getString("id"));
            String title = rs.getString("title");
            String startDate = rs.getString("startDate");
            String startTime = rs.getString("startTime");
            String endDate = rs.getString("endDate");
            String endTime = rs.getString("endTime");
            int roomId = Integer.parseInt(rs.getString("roomId"));
            String userName = rs.getString("userName");
            Booking book = new Booking();
            book.setId(id);
            book.setTitle(title);
            book.setStartDate(startDate);
            book.setStartTime(startTime);
            book.setEndDate(endDate);
            book.setEndTime(endTime);
            book.setRoomId(roomId);
            book.setUserName(userName);
            list.add(book);
        }
        return list;
    } 
 
    public static void deleteBooking(Connection conn, int id) throws SQLException {
        String sql = "Delete From events where id= ?";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        pstm.setInt(1, id);
 
        pstm.executeUpdate();
    }
}
 

