package crbs.beans;

import java.io.Serializable;

public class Room implements Serializable {

	    
	   private int roomID;
	   private String roomName;
	   private int roomCapacity;
	 
	   public Room() {
	        
	   }
	   
	   public Room(int roomID,String roomName, int roomCapacity) {
	        
		   this.roomID= roomID;
		   this.roomName= roomName;
		   this.roomCapacity= roomCapacity;
	   }
	    
	   public int getRoomID() {
	       return roomID;
	   }
	 
	   public void setRoomID(int roomID) {
	       this.roomID = roomID;
	   }
	 
	   public String getRoomName() {
	       return roomName;
	   }
	 
	   public void setRoomName(String roomName) {
	       this.roomName = roomName;
	   }
	   
	   public int getRoomCapacity() {
	       return roomCapacity;
	   }
	 
	   public void setRoomCapacity(int roomCapacity) {
	       this.roomCapacity = roomCapacity;
	   }

}

