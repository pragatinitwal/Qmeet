package crbs.beans;

public class AdminAccount {
	
	 public static final String GENDER_MALE ="M";
	   public static final String GENDER_FEMALE = "F";
	    
	   private String adminName;
	   private String password;
	   private String gender;
	 
	   public AdminAccount() {
	        
	   }
	   
	   public AdminAccount(String adminName,String password, String gender) {
	        
		   this.adminName= adminName;
		   this.password= password;
		   this.gender= gender;
	   }
	    
	   public String getAdminName() {
	       return adminName;
	   }
	 
	   public void setAdminName(String adminName) {
	       this.adminName = adminName;
	   }
	 
	   public String getPassword() {
	       return password;
	   }
	 
	   public void setPassword(String password) {
	       this.password = password;
	   }
	   
	   public String getGender() {
	       return gender;
	   }
	 
	   public void setGender(String gender) {
	       this.gender = gender;
	   }

}

