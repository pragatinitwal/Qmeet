package crbs.beans;

import java.io.Serializable;

public class Booking implements Serializable {
	
	private int id;
    private String title;
    private String startDate;
    private String startTime;
    private String endDate;
    private String endTime;
    private int roomId;
    private String userName;
    
    public Booking(){
    
    }
      
    public Booking (int id,String title,String startDate,String startTime,String endDate,String endTime, int roomId,String userName){
		
		   this.id=id;
			this.title=title;
			this.startDate=startDate;
			this.startTime=startTime;
			this.endDate= endDate;
			this.endTime=endTime;
			this.roomId= roomId;
			this.userName=userName;
			
	}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    
    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    
    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
    	this.endTime = endTime;
    }
    
    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
    	this.roomId = roomId;
    }
    
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
    	this.userName = userName;
    }

}
