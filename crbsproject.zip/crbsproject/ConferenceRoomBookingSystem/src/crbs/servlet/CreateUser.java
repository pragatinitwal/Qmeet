package crbs.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import crbs.beans.UserAccount;
import crbs.utils.DBUtils;
import crbs.utils.MyUtils;


@WebServlet("/createUser")
public class CreateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public CreateUser() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/WEB-INF/views/createUser.jsp");
        dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Connection conn = MyUtils.getStoredConnection(request);
		 
		int userID = Integer.parseInt(request.getParameter("userID"));
        String name = (String) request.getParameter("name");
        String email = (String) request.getParameter("email");
        String phone = (String) request.getParameter("phone");
        String userName = (String) request.getParameter("userName");
        String password = (String) request.getParameter("password");
        
        UserAccount user = new UserAccount(userID, name, email, phone, userName, password);
 
        String errorString = null;

        String regex = "\\w+";
 
        if (name == null && email == null && phone == null || !name.matches(regex)  ) {
            errorString = " please enter valid details. ";
        }
 
        if (errorString == null) {
            try {
                DBUtils.insertUserAccount(conn, user);
                JOptionPane.showMessageDialog(null, "user added Successfully!");
            } catch (SQLException e) {
                e.printStackTrace();
                errorString = e.getMessage();
            }
        }
 
        request.setAttribute("errorString", errorString);
        request.setAttribute("userAccount", user);
 
        if (errorString != null) {
            RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/WEB-INF/views/createUser.jsp");
            dispatcher.forward(request, response);
        }
       
        else {
        	
            response.sendRedirect(request.getContextPath() + "/userList");
        }
    }
	

}
