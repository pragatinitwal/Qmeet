package crbs.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import crbs.beans.Booking;
import crbs.utils.DBUtils;
import crbs.utils.MyUtils;


@WebServlet("/adminAddBooking")
public class AdminAddBooking extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public AdminAddBooking() {
        super();
        
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        Connection conn = MyUtils.getStoredConnection(request);
 
        int id= Integer.parseInt(request.getParameter("id"));
        String title = (String) request.getParameter("title");
        String startDate = (String) request.getParameter("startDate");
        String startTime = (String) request.getParameter("startTime");
        String endDate = (String) request.getParameter("endDate");
        String endTime = (String) request.getParameter("endTime");
        int roomId= Integer.parseInt(request.getParameter("roomId"));
        String userName = (String) request.getParameter("userName");
        
        Booking book = new Booking(id, title, startDate, startTime, endDate, endTime, roomId, userName);
 
        String errorString = null;

        String regex = "\\w+";
 
        if (title == null && startDate == null && startTime == null || !title.matches(regex)  ) {
            errorString = " please enter valid details. ";
        }
 
        if (errorString == null) {
            try {
                DBUtils.insertBooking(conn, book);
                JOptionPane.showMessageDialog(null, "Booking Registered Successfully!");
            } catch (SQLException ex) {
	            Logger.getLogger(CalendarJsonServlet.class.getName()).log(Level.SEVERE, null, ex);
	        }  
        }
 
        request.setAttribute("errorString", errorString);
        request.setAttribute("booking", book);
 
        if (errorString != null) {
            RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/WEB-INF/views/adminBooking.jsp");
            dispatcher.forward(request, response);
        }
       
        else {
        	errorString ="Booking successfully";
            response.sendRedirect(request.getContextPath() + "/adminBooking");
        }  
	}

}