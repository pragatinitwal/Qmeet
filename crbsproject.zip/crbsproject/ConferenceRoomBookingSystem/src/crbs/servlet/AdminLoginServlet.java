package crbs.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import crbs.beans.AdminAccount;
import crbs.utils.DBUtils;
import crbs.utils.MyUtils;

@WebServlet(urlPatterns = { "/adminLogin" })
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    public AdminLoginServlet() {
        super();
    }
 
    // Show Login page.
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
 
        RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/views/adminLogin.jsp");
 
        dispatcher.forward(request, response);
 
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
    	
        String adminName = request.getParameter("adminName");
        String password = request.getParameter("password");
        String rememberMeStr = request.getParameter("rememberMe");
        boolean remember = "Y".equals(rememberMeStr);
 
        AdminAccount admin = null;
        boolean hasError = false;
        String errorString = null;
 
        if (adminName == null || password == null || adminName.length() == 0 || password.length() == 0) {
            hasError = true;
            errorString = "Required username and password!";
        } 
        else {
            Connection conn = MyUtils.getStoredConnection(request);
            try {
                // Find the admin in the DB.
                admin = DBUtils.findAdmin(conn, adminName, password);
                JOptionPane.showMessageDialog(null, "LogIn Successfull!");
 
                if (admin == null) {
                    hasError = true;
                    errorString = " invalid User Name or password. ";
                }
            } catch (SQLException e) {
                e.printStackTrace();
                hasError = true;
                errorString = e.getMessage();
            }
        }
        // If error, forward to adminLogin.jsp
        if (hasError) {
            admin = new AdminAccount();
            admin.setAdminName(adminName);
            admin.setPassword(password);
 
            // Store information in request attribute, before forward.
            request.setAttribute("errorString", errorString);
            request.setAttribute("admin", admin);
 
            RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/views/adminLogin.jsp");
 
            dispatcher.forward(request, response);
        }
     
        else {
            HttpSession session = request.getSession();
            MyUtils.storeLoginedAdmin(session, admin);
 
            if (remember) {
                MyUtils.storeAdminCookie(response, admin);
            }
            // Else delete cookie.
            else {
                MyUtils.deleteAdminCookie(response);
            }
 
            // Redirect to Admin page.
            response.sendRedirect(request.getContextPath() + "/adminBooking");
        }
    }
 
}


