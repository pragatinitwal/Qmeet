package crbs.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import crbs.beans.Booking;

@WebServlet(name = "CalendarJsonServlet", urlPatterns = {"/CalendarJsonServlet"})
public class CalendarJsonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
    public CalendarJsonServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
            
            List progs = new ArrayList();
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "Priya123");
            ResultSet rs = conn.createStatement().executeQuery("SELECT `id`, `title`, `startDate`,`startTime`,`endDate`, `endTime`,`roomId` FROM `events`");
            
            while (rs.next()) {
                Booking book = new Booking();
                book.setId(Integer.parseInt(rs.getString(1)));
                book.setStartDate(rs.getString(3));
                book.setStartTime(rs.getString(4));
                book.setEndDate(rs.getString(5));
                book.setEndTime(rs.getString(6));
                book.setRoomId(Integer.parseInt(rs.getString(7)));
                book.setTitle(rs.getString(2));
                progs.add(book);
                
            }
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            PrintWriter out = response.getWriter();
            out.write(new Gson().toJson(progs));
            
           
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CalendarJsonServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(CalendarJsonServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
	}


}
