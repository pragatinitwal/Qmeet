package crbs.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
 
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import crbs.beans.UserAccount;
import crbs.utils.DBUtils;
import crbs.utils.MyUtils;
 
@WebServlet(urlPatterns = { "/registerUser" })
public class RegisterUser extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    public RegisterUser() {
        super();
    }
 
    // Show registration page.
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
 
        RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/WEB-INF/views/registerView.jsp");
        dispatcher.forward(request, response);
    }
 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        Connection conn = MyUtils.getStoredConnection(request);
 
        int userID= Integer.parseInt(request.getParameter("userID"));
        String name = (String) request.getParameter("name");
        String email = (String) request.getParameter("email");
        String phone = (String) request.getParameter("phone");
        String userName = (String) request.getParameter("userName");
        String password = (String) request.getParameter("password");
        
        UserAccount user = new UserAccount(userID, name, email, phone, userName, password);
 
        String errorString = null;

        String regex = "\\w+";
 
        if (name == null && email == null && phone == null || !name.matches(regex)  ) {
            errorString = " please enter valid details. ";
        }
 
        if (errorString == null) {
            try {
                DBUtils.insertUserAccount(conn, user);
                JOptionPane.showMessageDialog(null, "Register Successfully!");
            } catch (SQLException e) {
                e.printStackTrace();
                errorString = e.getMessage();
            }
        }
 
        request.setAttribute("errorString", errorString);
        request.setAttribute("userAccount", user);
 
        if (errorString != null) {
            RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/WEB-INF/views/registerView.jsp");
            dispatcher.forward(request, response);
        }
        // Redirect to the login page.
        else {
        	errorString ="Registeration successfully";
            response.sendRedirect(request.getContextPath() + "/login");
        }
    }
}
