package crbs.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import crbs.beans.Room;
import crbs.utils.DBUtils;
import crbs.utils.MyUtils;


@WebServlet("/createRoom")
public class CreateRoomServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public CreateRoomServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/WEB-INF/views/createRoom.jsp");
        dispatcher.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Connection conn = MyUtils.getStoredConnection(request);
		 
        int roomID =(int)(Integer.parseInt( request.getParameter("roomID")));
        String roomName = (String) request.getParameter("roomName");
        int roomCapacity = (int) (Integer.parseInt(request.getParameter("roomCapacity")));
        
        Room room = new Room( roomID, roomName, roomCapacity);
 
        String errorString = null;
       
        String regex = "\\w+";
 
        if (roomName == null || !roomName.matches(regex)) { 
            errorString = "Name invalid!";
        }
 
        if (errorString == null) {
            try {
                DBUtils.insertRoom(conn, room);
            } catch (SQLException e) {
                e.printStackTrace();
                errorString = e.getMessage();
            }
        }
 
        request.setAttribute("errorString", errorString);
        request.setAttribute("room", room);
 
        if (errorString != null) {
            RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/WEB-INF/views/createRoom.jsp");
            dispatcher.forward(request, response);
        }
       
        else {
            response.sendRedirect(request.getContextPath() + "/roomList");
        }
    }
 
}
